CREATE TRIGGER modifica
BEFORE UPDATE ON t_art
FOR EACH ROW
  BEGIN
UPDATE  t_version 
  SET ver=(1+ver) 
  WHERE  idv='1';
END;
