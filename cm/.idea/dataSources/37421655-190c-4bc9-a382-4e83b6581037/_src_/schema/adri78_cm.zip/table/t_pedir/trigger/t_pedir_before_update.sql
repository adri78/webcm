CREATE TRIGGER t_pedir_before_update
BEFORE UPDATE ON t_pedir
FOR EACH ROW
  BEGIN 
UPDATE t_version 
  SET ver=(1+ver) 
  WHERE  idv='2'; 
END;
