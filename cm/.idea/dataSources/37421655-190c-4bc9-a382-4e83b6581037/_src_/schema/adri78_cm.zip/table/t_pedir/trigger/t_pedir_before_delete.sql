CREATE TRIGGER t_pedir_before_delete
BEFORE DELETE ON t_pedir
FOR EACH ROW
  BEGIN 
UPDATE t_version 
  SET ver=(1+ver) 
  WHERE  idv='2'; 
END;
